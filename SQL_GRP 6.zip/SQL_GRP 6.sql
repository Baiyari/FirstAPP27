create database banking_system;
use banking_system;

-- Customer Table
CREATE TABLE Customer (
    customer_id INT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    dob DATE,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(15),
    address VARCHAR(255),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Branch Table
CREATE TABLE Branch (
    branch_id INT PRIMARY KEY,
    branch_name VARCHAR(100),
    address VARCHAR(255),
    manager VARCHAR(100)
);

-- Loan Table
CREATE TABLE Loan (
    loan_id INT PRIMARY KEY,
    customer_id INT NOT NULL,
    loan_type VARCHAR(50) NOT NULL,
    principal DECIMAL(15,2) NOT NULL CHECK (principal > 0),
    interest_rate DECIMAL(5,2) NOT NULL,
    start_date DATE DEFAULT (CURRENT_DATE),
    duration_months INT,
    status varchar(50) CHECK(status IN ('Active','Closed','Defaulted')) DEFAULT 'Active',
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id) ON DELETE CASCADE
);

-- Account Table
CREATE TABLE Account (
    account_id INT PRIMARY KEY,
    account_number VARCHAR(20) UNIQUE NOT NULL,
    customer_id INT NOT NULL,
    branch_id INT NOT NULL,
    account_type varchar(20) CHECK(account_type IN ('Savings','Current','Fixed')) NOT NULL,
    balance DECIMAL(15,2) NOT NULL DEFAULT 0.0,
    opened_date DATE DEFAULT (CURRENT_DATE),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (branch_id) REFERENCES Branch(branch_id) ON DELETE CASCADE
);

-- Transactions Table
CREATE TABLE Transactions (
    transaction_id INT PRIMARY KEY,
    account_id INT NOT NULL,
    txn_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    txn_type varchar(20) CHECK(txn_type IN ('Credit','Debit')) NOT NULL,
    amount DECIMAL(15,2) NOT NULL CHECK (amount >= 0),
    description VARCHAR(255),
    balance_after DECIMAL(15,2),
    FOREIGN KEY (account_id) REFERENCES Account(account_id) ON DELETE CASCADE
);


-- Customer Table Data
INSERT INTO Customer (customer_id, first_name, last_name, dob, email, phone, address) VALUES
(1,'Vansh','Kapoor','2001-04-21','vansh.kapoor@example.com','9821805852','Delhi'),
(2,'Saiesh','Gaikar','1999-02-13','saiesh.gaikar@example.com','9876545210','Nashik'),
(3,'Shreyansh','Joshi','1999-02-27','shreyansh.joshi@example.com','8886543740','Delhi'),
(4,'Vedant','Shrikhande','1998-10-19','vedant.shrikhande@example.com','7756544510','Nagpur'),
(5,'Flora','Desai','2002-03-08','flora.desai@example.com','8956543210','Mumbai'),
(6,'Adithi','Garikipati','2000-11-05','adithi.garikipati@example.com','9876545623','Hyderabad'),
(7,'Bhagyashree','Kapate','2001-10-23','bhagyashree.kapate@example.com','8521479635','Nagpur'),
(8,'Abhinav','Reddy','1998-12-12','abhinav.reddy@example.com','7418529635','Hyderabad'),
(9,'Dayita','Ghosh','2001-07-24','dayita.ghosh@example.com','9123784560','Kolkata'),
(10,'Harshita','Sharma','2002-03-14','harshita.sharma@example.com','7845656780','Nagpur'),
(11,'Ninad','Mehta','1999-02-28','ninad.mehta@example.com','7894566780','Nagpur'),
(12,'Ayurda','Dhar','2001-05-03','ayurda.dhar@example.com','9123474580','Delhi'),
(13,'Baiyari','Debbarma','1998-11-30','baiyari.debbarma@example.com','8741456780','Mumbai'),
(14,'Anirudh','Gaikwad','2001-04-22','anirudh.gaikwad@example.com','9865256780','Nashik'),
(15,'Sahil','Utkarsh','1997-09-05','sahil.utkarsh@example.com','9632587415','Mumbai'),
(16,'Aman','Verma','1988-05-20','aman.verma@example.com','9876543210','Delhi'),
(17,'Riya','Sharma','1992-11-03','riya.sharma@example.com','9123456780','Mumbai'),
(18,'Vikram','Singh','1978-02-14','vikram.singh@example.com','9988776655','Bengaluru'),
(19,'Neha','Kumar','1999-07-30','neha.kumar@example.com','9012345678','Chennai'),
(20,'Suresh','Patel','1985-09-10','suresh.patel@example.com','8899776655','Ahmedabad');

Select * from Customer;

-- Transaction Table Data
INSERT INTO Transactions (transaction_id, account_id, txn_date, txn_type, amount, description, balance_after) VALUES
(1, 1, '2024-07-01', 'Credit', 10000, 'Salary Deposit', 60000),
(2, 1, '2024-07-05', 'Debit', 2000, 'ATM Withdrawal', 58000),
(3, 2, '2024-08-02', 'Credit', 5000, 'Interest Credit', 105000),
(4, 3, '2024-06-12', 'Debit', 1000, 'Bill Payment', 24000),
(5, 4, '2024-07-10', 'Credit', 7000, 'Online Transfer', 82000),
(6, 5, '2024-05-22', 'Debit', 15000, 'Cheque Payment', 135000),
(7, 6, '2024-08-14', 'Credit', 8000, 'Bonus', 50000),
(8, 7, '2024-07-25', 'Debit', 2000, 'Shopping', 10000),
(9, 8, '2024-06-19', 'Credit', 6000, 'Maturity Payout', 66000),
(10,9, '2024-09-01', 'Debit', 500, 'Mobile Recharge', 3500),
(11,10,'2024-07-16', 'Credit', 2500, 'Transfer In', 33000),
(12,11,'2024-08-20', 'Credit', 4000, 'Freelance Payment', 22000),
(13,12,'2024-06-18', 'Debit', 3000, 'Rent Payment', 72000),
(14,13,'2024-05-10', 'Credit', 2000, 'Scholarship', 11500),
(15,14,'2024-07-14', 'Debit', 5000, 'Shopping', 38000),
(16,15,'2024-06-22', 'Credit', 12000, 'Salary', 67000),
(17,16,'2024-07-28', 'Debit', 10000, 'Car EMI', 110000),
(18,17,'2024-08-11', 'Credit', 3000, 'Transfer In', 25000),
(19,18,'2024-07-05', 'Debit', 2000, 'Utility Bill', 64000),
(20,19,'2024-09-12', 'Credit', 5000, 'Gift', 22000);

Select * from Transactions;

-- Loan Table Data
INSERT INTO Loan (loan_id, customer_id, loan_type, principal, interest_rate, start_date, duration_months, status) VALUES
(1, 1, 'Car Loan', 800000, 9.0, '2022-01-10', 60, 'Active'),
(2, 1, 'Personal Loan', 200000, 12.0, '2023-05-20', 36, 'Active'),
(3, 2, 'Home Loan', 3500000, 7.5, '2021-04-15', 240, 'Active'),
(4, 2, 'Education Loan', 500000, 10.5, '2020-08-01', 84, 'Closed'),
(5, 3, 'Business Loan', 1000000, 11.0, '2022-03-12', 48, 'Active'),
(6, 3, 'Personal Loan', 150000, 14.0, '2021-09-15', 36, 'Closed'),
(7, 4, 'Home Loan', 4200000, 7.8, '2019-12-10', 240, 'Active'),
(8, 4, 'Vehicle Loan', 600000, 8.5, '2022-07-01', 60, 'Active'),
(9, 5, 'Gold Loan', 300000, 13.0, '2023-02-22', 24, 'Active'),
(10,5, 'Personal Loan', 100000, 14.5, '2021-05-30', 36, 'Closed'),
(11,6, 'Home Loan', 2800000, 7.9, '2020-11-11', 180, 'Active'),
(12,6, 'Education Loan', 450000, 10.2, '2023-01-05', 84, 'Active'),
(13,7, 'Car Loan', 900000, 9.2, '2022-09-20', 72, 'Active'),
(14,7, 'Business Loan', 1200000, 11.5, '2021-03-17', 48, 'Closed'),
(15,8, 'Home Loan', 5000000, 7.6, '2018-05-01', 240, 'Active'),
(16,8, 'Gold Loan', 350000, 12.5, '2023-06-10', 24, 'Active'),
(17,9, 'Education Loan', 600000, 10.0, '2019-07-22', 84, 'Closed'),
(18,9, 'Vehicle Loan', 750000, 8.8, '2021-09-11', 60, 'Active'),
(19,10,'Business Loan', 2000000, 11.0, '2020-10-02', 60, 'Defaulted'),
(20,10,'Personal Loan', 180000, 13.5, '2022-12-25', 36, 'Active');

-- Account Table Data
INSERT INTO Account (account_id, account_number, customer_id, branch_id, account_type, balance, opened_date) VALUES
(1, 'ACC100001', 1, 1, 'Savings', 50000, '2020-01-15'),
(2, 'ACC100002', 1, 1, 'Fixed', 100000, '2021-06-01'),
(3, 'ACC200001', 2, 2, 'Savings', 25000, '2019-03-10'),
(4, 'ACC200002', 2, 2, 'Current', 75000, '2021-09-12'),
(5, 'ACC300001', 3, 3, 'Current', 150000, '2018-08-20'),
(6, 'ACC300002', 3, 3, 'Savings', 42000, '2020-02-14'),
(7, 'ACC400001', 4, 4, 'Savings', 12000, '2022-11-05'),
(8, 'ACC400002', 4, 4, 'Fixed', 60000, '2023-04-21'),
(9, 'ACC500001', 5, 5, 'Savings', 4000, '2024-02-10'),
(10,'ACC500002', 5, 5, 'Current', 30500, '2023-05-20'),
(11,'ACC600001', 6, 6, 'Savings', 18000, '2023-07-15'),
(12,'ACC600002', 6, 6, 'Fixed', 75000, '2022-12-12'),
(13,'ACC700001', 7, 7, 'Savings', 9500, '2024-01-10'),
(14,'ACC700002', 7, 7, 'Current', 43000, '2023-09-18'),
(15,'ACC800001', 8, 8, 'Savings', 55000, '2021-05-14'),
(16,'ACC800002', 8, 8, 'Fixed', 120000, '2019-10-25'),
(17,'ACC900001', 9, 9, 'Savings', 22000, '2022-06-30'),
(18,'ACC900002', 9, 9, 'Current', 66000, '2023-08-21'),
(19,'ACC100003', 10, 10, 'Savings', 17000, '2023-03-11'),
(20,'ACC110001', 10, 10, 'Current', 28500, '2024-02-01');

-- Branch Table Data
INSERT INTO Branch (branch_id, branch_name, address, manager) VALUES
(1, 'Delhi Main Branch', 'Connaught Place, Delhi', 'Mr. Arvind Mehra'),
(2, 'Mumbai Central Branch', 'Nariman Point, Mumbai', 'Ms. Neha Kapoor'),
(3, 'Bengaluru City Branch', 'MG Road, Bengaluru', 'Mr. Rakesh Rao'),
(4, 'Chennai Anna Nagar Branch', 'Anna Nagar, Chennai', 'Ms. Priya Iyer'),
(5, 'Ahmedabad CG Road Branch', 'CG Road, Ahmedabad', 'Mr. Sunil Patel'),
(6, 'Kolkata Park Street Branch', 'Park Street, Kolkata', 'Mr. Anirban Chatterjee'),
(7, 'Hyderabad Banjara Hills Branch', 'Banjara Hills, Hyderabad', 'Ms. Kavya Reddy'),
(8, 'Pune FC Road Branch', 'FC Road, Pune', 'Mr. Nitin Joshi'),
(9, 'Jaipur MI Road Branch', 'MI Road, Jaipur', 'Ms. Shalini Singh'),
(10,'Lucknow Hazratganj Branch', 'Hazratganj, Lucknow', 'Mr. Rajesh Verma'),
(11,'Chandigarh Sector 17 Branch', 'Sector 17, Chandigarh', 'Ms. Simran Kaur'),
(12,'Indore Vijay Nagar Branch', 'Vijay Nagar, Indore', 'Mr. Deepak Malhotra'),
(13,'Nagpur Sitabuldi Branch', 'Sitabuldi, Nagpur', 'Ms. Ritu Sharma'),
(14,'Surat Ring Road Branch', 'Ring Road, Surat', 'Mr. Hemant Desai'),
(15,'Kanpur Mall Road Branch', 'Mall Road, Kanpur', 'Ms. Aarti Srivastava'),
(16,'Bhopal New Market Branch', 'New Market, Bhopal', 'Mr. Sandeep Tiwari'),
(17,'Patna Gandhi Maidan Branch', 'Gandhi Maidan, Patna', 'Ms. Poonam Sinha'),
(18,'Coimbatore RS Puram Branch', 'RS Puram, Coimbatore', 'Mr. Ravi Krishnan'),
(19,'Thiruvananthapuram MG Road Branch', 'MG Road, Trivandrum', 'Ms. Anusha Nair'),
(20,'Mysuru Devaraja Branch', 'Devaraja Mohalla, Mysuru', 'Mr. Kiran Shetty');

Select * from Branch;
Select * from Account;
Select * from Transactions;
Select * from Loan;

-- 1. List customers with their accounts
SELECT 
    c.customer_id, 
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    a.account_number, 
    a.account_type, 
    a.balance, 
    b.branch_name
FROM Customer c
JOIN Account a ON c.customer_id = a.customer_id
JOIN Branch b ON a.branch_id = b.branch_id
ORDER BY c.customer_id;

-- 2. Account statement for a given account (e.g., ACC100001)
SELECT 
    t.transaction_id,
    t.txn_date, 
    t.txn_type, 
    t.amount, 
    t.description, 
    t.balance_after
FROM Transactions t
JOIN Account a ON t.account_id = a.account_id
WHERE a.account_number = 'ACC100001'
ORDER BY t.txn_date DESC;

-- 3. Total balance per customer
SELECT 
    c.customer_id, 
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    SUM(a.balance) AS total_balance
FROM Customer c
JOIN Account a ON c.customer_id = a.customer_id
GROUP BY c.customer_id
ORDER BY total_balance DESC;

-- 4. Active loans with customer details
SELECT 
    l.loan_id, 
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    l.loan_type, 
    l.principal, 
    l.interest_rate, 
    l.start_date, 
    l.duration_months, 
    l.status
FROM Loan l
JOIN Customer c ON l.customer_id = c.customer_id
WHERE l.status = 'Active'
ORDER BY l.start_date;

-- 5. Update Example: Credit ₹500 to Account -> ACC400001
-- Step 1: Update the balance in Account
UPDATE Account 
SET balance = balance + 500 
WHERE account_number = 'ACC400001';

-- Step 2: Insert a new transaction
INSERT INTO Transactions (transaction_id, account_id, txn_date, txn_type, amount, description, balance_after)
VALUES (
    21,  -- you must provide next available transaction_id
    (SELECT account_id FROM Account WHERE account_number = 'ACC400001'),
    NOW(), 
    'Credit', 
    500, 
    'Manual credit',
    (SELECT balance FROM Account WHERE account_number = 'ACC400001')
);

-- 6. Changing the account type
UPDATE Account
SET account_type = 'Current'
WHERE account_number = 'ACC100001';

-- 7.Finding High-Value customer
SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    c.email,
    c.phone,
    SUM(a.balance) AS total_balance
FROM 
    Customer c
JOIN 
    Account a ON c.customer_id = a.customer_id
GROUP BY 
    c.customer_id, c.first_name, c.last_name, c.email, c.phone
HAVING 
    SUM(a.balance) > 100000
ORDER BY 
    total_balance DESC;
    
-- 7.Most active customer
SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    COUNT(t.transaction_id) AS total_transactions
FROM 
    Customer c
JOIN 
    Account a ON c.customer_id = a.customer_id
JOIN 
    Transactions t ON a.account_id = t.account_id
GROUP BY 
    c.customer_id, c.first_name, c.last_name
ORDER BY 
    total_transactions DESC
LIMIT 1;

-- Functions
-- Deposit Balance
SELECT deposit_balance(1, 5000);

-- Withdrawals
SELECT withdraw_balance(1, 2000);

-- Interest Calculation
SELECT calculate_interest('ACC100002', 5.00, 2);

-- Transfer money
SELECT transfer_money('ACC100001', 'ACC100003', 500.00) AS Result;

-- Monthly Depositsmonthly_deposits
SELECT monthly_deposits(1, 2024, 07) AS TotalDeposits;



